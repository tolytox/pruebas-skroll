
require('./src/Animate');
require('./src/Scroller');

module.exports = Scroller;